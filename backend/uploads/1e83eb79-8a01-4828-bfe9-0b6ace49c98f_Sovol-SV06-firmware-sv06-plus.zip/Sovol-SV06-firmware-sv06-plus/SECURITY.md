# Security Policy

## Reporting a Vulnerability

If you see any piece of code on this repository that could be a security issue, please create an [Issue](https://github.com/bassamanator/Sovol-SV06-firmware/issues/new/choose) at your earliest continence. I keep a close eye on this repository, so you should get an update from me fairly quickly.

You can also message me on [Reddit](https://www.reddit.com/user/bassamanator/) privately.

If your reported vulnerability is confirmed, you can rest assured that dealing with it will be a top priority.
